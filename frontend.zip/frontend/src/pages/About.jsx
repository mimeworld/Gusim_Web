import { PageTitle } from "../components";
const Activity = ({ icon, title, children }) => (
  <div className="activity">
    <i>{icon}</i>
    <div>
      <h3>{title}</h3>
      <p>{children}</p>
    </div>
  </div>
);
export default function About() {
  return (
    <>
      <PageTitle eyebrow="ABOUT US" title="구도와 심도는?" />
      <main className="shell about">
        <p>
          2024년 12월에 창설되어, 카메라와 사진 찍는 것을 좋아하는 사람들이 모인
          소모임입니다. 사진에 열정을 가지고 함께 재밌게 활동하며, 특별한
          순간들을 함께 만들어갈 많은 학우분들의 지원 부탁드립니다:)
        </p>
        <hr />
        <h2>활동 내용</h2>
        <Activity icon="📷" title="정기 출사">
          매달 주말(토/일) 진행을 기본으로 하되, 연휴·시험기간 등은 구성원
          의견을 수렴하여 유동적으로 조율합니다.
        </Activity>
        <Activity icon="📽️" title="정기 크리틱">
          출사 주 또는 그 다음 주 평일 저녁에 진행 예정이며, 포트폴리오 구성,
          장비 교육 등 더 폭넓은 활동을 계획하고 있습니다.
        </Activity>
        <Activity icon="🔥" title="연합 출사">
          가천대학교를 대표하여 전국 10개 대학의 사진에 진심인 동아리들과 대규모
          정기 연합출사를 진행할 예정입니다. 4회째 이어 오고 있으며, 사진에 대한
          다양한 세계관을 깊고 넓게 만들 수 있는 좋은 기회입니다.
        </Activity>
        <p>
          그 외에도 다양한 전시회와 사진 명소 방문, 사진 관련 자유 활동을
          진행하며 학기말 전시회 개최 또는 사진집 발간도 할 예정입니다.
        </p>
        <blockquote>
          ‘구도와심도’라는 이름 아래, 여러분들과 더 멋진 사진과 추억을 함께
          만들어갈 수 있기를 기대합니다.
        </blockquote>
      </main>
    </>
  );
}
