import MemberBadges from "../components/MemberBadges";
import { UserRound } from "lucide-react";
import { Link } from "react-router-dom";
import { useState } from "react";
import { api, upload } from "../services/community";
import { PageTitle } from "../components";
import { useApp } from "../context";
export default function MyPage() {
  const { profile, posts, logout, refreshProfile } = useApp();
  const [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  async function avatar(event) {
    const file = event.target.files?.[0];
    if (!file) return;
    setBusy(true);
    try {
      const url = await upload(file);
      await api("/me", {
        method: "PUT",
        body: JSON.stringify({
          name: profile.name,
          bio: profile.bio,
          avatar: url,
        }),
      });
      await refreshProfile();
      setError("");
    } catch (error) {
      setError(error.message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <PageTitle eyebrow="MY PAGE" title="마이페이지" />
      <main className="shell grid gap-8 py-12 md:grid-cols-[280px_1fr]">
        <aside className="panel h-fit space-y-5 text-center">
          <div className="mx-auto grid size-24 place-items-center overflow-hidden rounded-full bg-club-50 text-club-700">
            {profile.avatar ? (
              <img
                src={profile.avatar}
                alt="내 프로필"
                className="size-full object-cover"
              />
            ) : (
              <UserRound size={40} />
            )}
          </div>
          <h2>{profile.name}</h2>
          <MemberBadges tags={profile.tags} className="justify-center" />
          <p className="text-sm text-slate-500">
            {profile.role === "ADMIN" ? "관리자" : "일반 부원"} ·{" "}
            {profile.studentNumber}
          </p>
          <label>
            프로필 사진 변경
            <input
              type="file"
              accept="image/jpeg,image/png"
              onChange={avatar}
              disabled={busy}
            />
          </label>
          <button
            className="secondary"
            onClick={() => logout().catch((e) => setError(e.message))}
          >
            로그아웃
          </button>
          {error && (
            <p className="alert" role="alert">
              {error}
            </p>
          )}
        </aside>
        <div className="space-y-8">
          <section className="panel">
            <div className="section-head">
              <h2>내 카메라 장비</h2>
              <Link className="text-button" to="/equipment">
                장비 관리 →
              </Link>
            </div>
            {profile.equipment.length ? (
              profile.equipment.map((g) => (
                <p className="border-b border-slate-100 py-3" key={g.id}>
                  {g.type} · {g.maker} {g.model}
                </p>
              ))
            ) : (
              <p className="text-slate-500">등록된 장비가 없습니다.</p>
            )}
          </section>
          <section className="panel">
            <div className="section-head">
              <h2>내 사진</h2>
              <Link className="text-button" to="/mypage/photos">
                내 사진 보기 →
              </Link>
            </div>
            <p>
              최근 공개 목록에 내가 작성한 사진{" "}
              {posts.filter((p) => p.authorId === profile.id).length}개
            </p>
          </section>
        </div>
      </main>
    </>
  );
}
