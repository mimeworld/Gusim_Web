import { Camera } from "lucide-react";
import { PageTitle } from "../components";
export default function Activities() {
  return (
    <>
      <PageTitle eyebrow="OUR ARCHIVE" title="동아리 활동 내역">
        <p>기수별로 쌓아가는 구도와 심도의 기록입니다.</p>
      </PageTitle>
      <main className="shell archive">
        <section>
          <div className="section-head">
            <h2>1기 활동 기록</h2>
            <span>2024.12 — NOW</span>
          </div>
          <div className="empty">
            <Camera size={34} />
            <h3>활동 사진을 준비하고 있어요</h3>
            <p>활동 기록을 정리하고 있습니다.</p>
          </div>
        </section>
        <section className="future">
          <h2>다음 기수의 기록을 기다립니다.</h2>
          <p>각 기수의 활동 사진과 이야기가 이곳에 차곡차곡 쌓일 예정입니다.</p>
        </section>
      </main>
    </>
  );
}
