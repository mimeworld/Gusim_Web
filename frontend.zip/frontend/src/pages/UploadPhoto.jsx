import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { PageTitle } from "../components";
import { useApp } from "../context";
import { api, upload } from "../services/community";
export default function UploadPhoto() {
  const { refreshPosts } = useApp();
  const nav = useNavigate();
  const [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  async function submit(e) {
    e.preventDefault();
    const data = new FormData(e.target);
    setBusy(true);
    try {
      const image = await upload(data.get("photo"));
      await api("/posts", {
        method: "POST",
        body: JSON.stringify({
          title: data.get("title"),
          content: data.get("content"),
          category: "PHOTO",
          image,
        }),
      });
      await refreshPosts();
      nav("/share");
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <PageTitle eyebrow="SHARE A PHOTO" title="사진 공유하기" />
      <main className="shell upload-page">
        <form onSubmit={submit} className="post-form">
          <label>
            사진 (JPEG/PNG, 10MB·2400만 화소 이하)
            <input
              type="file"
              name="photo"
              required
              accept="image/jpeg,image/png"
            />
          </label>
          <label>
            제목
            <input name="title" required maxLength={200} />
          </label>
          <label>
            사진 이야기
            <textarea name="content" maxLength={20000} />
          </label>
          {error && <p role="alert">{error}</p>}
          <button className="button" disabled={busy}>
            {busy ? "업로드 중…" : "사진 공유하기"}
          </button>
        </form>
      </main>
    </>
  );
}
