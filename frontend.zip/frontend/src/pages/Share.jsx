import MemberBadges from "../components/MemberBadges";
import { Camera, ImagePlus } from "lucide-react";
import { Link } from "react-router-dom";
import { PageTitle } from "../components";
import { useApp } from "../context";
export default function Share() {
  const { posts } = useApp();
  return (
    <>
      <PageTitle eyebrow="PHOTO COMMUNITY" title="사진 공유">
        <p>구심인들이 포착한 순간을 만나보세요.</p>
      </PageTitle>
      <main className="shell gallery-page">
        <div className="section-head">
          <div>
            <h2>모든 사진</h2>
            <span>{posts.length}장의 기록</span>
          </div>
          <Link className="upload-action" to="/share/upload">
            <ImagePlus size={20} />
            <span>사진 공유하기</span>
          </Link>
        </div>
        {posts.length ? (
          <div className="photo-grid">
            {posts.map((p) => (
              <article className="gallery-card" key={p.id}>
                {p.image ? (
                  <img src={p.image} alt={p.title} />
                ) : (
                  <div className="image-placeholder">
                    <Camera />
                  </div>
                )}
                <div>
                  <span>
                    {p.author} · {new Date(p.date).toLocaleDateString("ko-KR")}
                  </span>
                  <MemberBadges tags={p.authorTags} className="mt-2" />
                  <h3>{p.title}</h3>
                </div>
              </article>
            ))}
          </div>
        ) : (
          <div className="empty">
            <ImagePlus size={34} />
            <h3>아직 공유된 사진이 없어요</h3>
            <p>오른쪽의 사진 공유하기 버튼으로 첫 기록을 남겨보세요.</p>
          </div>
        )}
      </main>
    </>
  );
}
