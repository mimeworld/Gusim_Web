import { useEffect, useState } from "react";
import { api, upload } from "../services/community";
import { PageTitle } from "../components";
import MemberBadges from "../components/MemberBadges";
export default function Board({ category, title }) {
  const [posts, setPosts] = useState([]),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [file, setFile] = useState(null),
    [preview, setPreview] = useState("");
  const isCritique = category === "CRITIQUE";
  const refresh = () => api("/posts?category=" + category).then(setPosts);
  useEffect(() => {
    if (!file) {
      setPreview("");
      return;
    }
    const url = URL.createObjectURL(file);
    setPreview(url);
    return () => URL.revokeObjectURL(url);
  }, [file]);
  useEffect(() => {
    let active = true;
    setPosts([]);
    setError("");
    api("/posts?category=" + category)
      .then((p) => {
        if (active) setPosts(p);
      })
      .catch((e) => {
        if (active) setError(e.message);
      });
    return () => {
      active = false;
    };
  }, [category]);
  async function submit(event) {
    event.preventDefault();
    const form = event.currentTarget;
    const data = new FormData(form);
    setBusy(true);
    setError("");
    try {
      const image = isCritique ? await upload(data.get("photo")) : "";
      await api("/posts", {
        method: "POST",
        body: JSON.stringify({
          title: data.get("title"),
          content: data.get("content"),
          category,
          image,
        }),
      });
      await refresh();
      form.reset();
      setFile(null);
    } catch (error) {
      setError(error.message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <PageTitle eyebrow="MEMBERS COMMUNITY" title={title}>
        {isCritique && (
          <p>사진과 함께 촬영 의도, 의견을 듣고 싶은 부분을 남겨주세요.</p>
        )}
      </PageTitle>
      <main className="shell page-body">
        <form className="post-form" onSubmit={submit}>
          {isCritique && (
            <>
              <label>
                크리틱 사진 (JPEG/PNG, 10MB·2400만 화소 이하)
                <input
                  type="file"
                  name="photo"
                  accept="image/jpeg,image/png"
                  required
                  disabled={busy}
                  onChange={(e) => setFile(e.target.files?.[0] || null)}
                />
              </label>
              {preview && (
                <img
                  src={preview}
                  alt="크리틱 사진 미리보기"
                  className="max-h-80 w-full rounded-lg object-contain"
                />
              )}
            </>
          )}
          <label>
            제목
            <input name="title" required maxLength={200} disabled={busy} />
          </label>
          <label>
            내용
            <textarea
              name="content"
              required
              maxLength={20000}
              disabled={busy}
            />
          </label>
          <button className="button" disabled={busy}>
            {busy ? "등록 중…" : isCritique ? "사진과 크리틱 등록" : "글 등록"}
          </button>
        </form>
        {error && (
          <p className="alert mt-5" role="alert">
            {error}
          </p>
        )}
        {posts.length ? (
          posts.map((p) => (
            <article className="board-post" key={p.id}>
              <div className="flex flex-wrap items-center gap-3">
                <small>
                  {p.author} · {new Date(p.date).toLocaleDateString("ko-KR")}
                </small>
                <MemberBadges tags={p.authorTags} />
              </div>
              <h2>{p.title}</h2>
              {p.image && (
                <img
                  src={p.image}
                  alt={p.title}
                  loading="lazy"
                  className="max-h-[640px] w-full rounded-xl border border-slate-100 bg-slate-50 object-contain"
                />
              )}
              <p>{p.content}</p>
            </article>
          ))
        ) : (
          <div className="empty mt-8">아직 등록된 글이 없습니다.</div>
        )}
      </main>
    </>
  );
}
